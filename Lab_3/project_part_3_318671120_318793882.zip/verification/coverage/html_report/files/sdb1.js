var g_db_data = {"1":1};
processScopesDbFile(g_db_data);